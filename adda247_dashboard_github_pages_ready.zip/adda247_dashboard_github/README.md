# Adda247 Lead Priority Dashboard

GitHub Pages ready dashboard.

## Files
- `index.html` - dashboard UI
- `data/leads.csv` - lead data used by the dashboard

## Deploy on GitHub Pages
1. Create a new GitHub repository.
2. Upload the contents of this folder, not the ZIP itself.
3. Go to Settings > Pages.
4. Select branch `main` and folder `/root`.
5. Open the Pages URL after deployment.

Note: Open via GitHub Pages or a local server. Directly opening `index.html` from file system may block CSV loading in some browsers.
